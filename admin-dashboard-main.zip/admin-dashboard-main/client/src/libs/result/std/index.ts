import { as_result } from "..";

export const tryParseInt = as_result(parseInt);
