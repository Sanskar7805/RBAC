export * from "./custom-env";

export default {
  appName: "Dashboard",
  appLogo:
    "https://i.pinimg.com/736x/0d/5c/fb/0d5cfb72a2eda8474ea7a7cdc47ac099.jpg",
  showBanner: false,
};
