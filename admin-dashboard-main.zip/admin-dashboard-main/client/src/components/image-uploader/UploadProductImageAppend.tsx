export function UploadProductImageAppend() {
  return <div>UploadProductImageAppend</div>;
}
