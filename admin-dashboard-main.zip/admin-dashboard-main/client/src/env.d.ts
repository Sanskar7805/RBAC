interface ImportMetaEnv {
  MODE:
    | "production"
    | "development";

  HTTPS: boolean;
  VITE_GOOGLE_OAUTH_CLIENT_ID: string;
  VITE_GOOGLE_OAUTH_CLIENT_SECRET: string;
  VITE_GOOGLE_OAUTH_REDIRECT: string;

  BACKEND_ENDPOINT: string;
}
