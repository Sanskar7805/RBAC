export * from "./useGetShopowner";
export * from "./useGetShopowners";

export * from "./useCreateMultiShopowners";
export * from "./useCreateShopowner";

export * from "./useDeleteMultiShopowners";
export * from "./useDeleteShopowner";

export * from "./useUpdateShopowner";
