export * from "./useGetPermission";
export * from "./useGetPermissions";

export * from "./useCreateMultiPermissions";
export * from "./useCreatePermission";

export * from "./useDeleteMultiPermissions";
export * from "./useDeletePermission";

export * from "./useUpdatePermission";
